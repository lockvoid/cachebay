/**
 * Injection key for Cachebay instance in Vue's provide/inject system
 */
export const CACHEBAY_KEY = Symbol("CACHEBAY_KEY");
