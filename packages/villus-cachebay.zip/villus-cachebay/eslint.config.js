import lockvoidConfig from '@lockvoid/eslint-config';

export default [
  ...lockvoidConfig,
];
