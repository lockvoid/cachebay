// internals.ts - entry point

import {
  reactive,
  shallowReactive,
  isReactive,
  ref,
  type App,
} from "vue";
import type { ClientPlugin } from "villus";

import { relay } from "../resolvers/relay";
import { buildCachebayPlugin, provideCachebay } from "./plugin";
import { createModifyOptimistic } from "../features/optimistic";
import { createSSRFeatures } from "../features/ssr";
import { createInspect } from "../features/debug";

import type {
  CachebayOptions,
  KeysConfig,
  ResolversFactory,
  ResolversDict,
  FieldResolver,
} from "../types";
import type {
  CachebayInternals,
  EntityKey,
  ConnectionState,
  RelayOptions,
} from "./types";

import {
  stableIdentityExcluding,
  readPathValue,
  parseEntityKey,
  buildConnectionKey,
} from "./utils";

// split modules
import { createGraph } from "./graph";
import { createViews } from "./views";
import {
  bindResolversTree,
  makeApplyFieldResolvers,
  applyResolversOnGraph as applyResolversOnGraphImpl,
  getRelayOptionsByType,
  setRelayOptionsByType,
  relayResolverIndex,
  relayResolverIndexByType,
} from "./resolvers";
import { createFragmentsAPI } from "./fragments";

/* ─────────────────────────────────────────────────────────────────────────────
 * Public instance type
 * ──────────────────────────────────────────────────────────────────────────── */
export type CachebayInstance = ClientPlugin & {
  dehydrate: () => any;
  hydrate: (
    input: any | ((hydrate: (snapshot: any) => void) => void),
    opts?: { materialize?: boolean; rabbit?: boolean }
  ) => void;

  identify: (obj: any) => string | null;

  readFragment: (refOrKey: string | { __typename: string; id?: any; _id?: any }, materialized?: boolean) => any;
  hasFragment: (refOrKey: string | { __typename: string; id?: any; _id?: any }) => boolean;
  writeFragment: (obj: any) => { commit(): void; revert(): void };

  modifyOptimistic: (build: (cache: any) => void) => { commit(): void; revert(): void };

  inspect: {
    entities: (typename?: string) => string[];
    get: (key: string) => any;
    connections: () => string[];
    connection: (
      parent: "Query" | { __typename: string; id?: any; _id?: any },
      field: string,
      variables?: Record<string, any>,
    ) => any;
    operations?: () => Array<{ key: string; variables: Record<string, any>; data: any }>;
  };

  listEntityKeys: (selector: string | string[]) => string[];
  listEntities: (selector: string | string[], materialized?: boolean) => any[];
  __entitiesTick: ReturnType<typeof ref<number>>;

  gc?: { connections: (predicate?: (key: string, state: ConnectionState) => boolean) => void };

  install: (app: App) => void;
};

/* ─────────────────────────────────────────────────────────────────────────────
 * Factory
 * ──────────────────────────────────────────────────────────────────────────── */
export function createCache(options: CachebayOptions = {}): CachebayInstance {
  // Config
  const TYPENAME_KEY = options.typenameKey || "__typename";
  const DEFAULT_WRITE_POLICY = options.writePolicy || "replace";
  const typeKeyFactories =
    typeof options.keys === "function" ? options.keys() : options.keys ? options.keys : ({} as NonNullable<KeysConfig>);
  const customIdFromObject = options.idFromObject || null;
  const shouldAddTypename = options.addTypename !== false;

  const interfaceMap: Record<string, string[]> =
    typeof options.interfaces === "function"
      ? options.interfaces()
      : options.interfaces
        ? (options.interfaces as Record<string, string[]>)
        : {};

  const useShallowEntities = options.entityShallow === true;
  const trackNonRelayResults = options.trackNonRelayResults !== false;
  const OP_CACHE_MAX =
    typeof options.lruOperationCacheSize === "number"
      ? Math.max(1, options.lruOperationCacheSize)
      : 200;

  // Build raw graph (stores + helpers)
  const graph = createGraph({
    TYPENAME_KEY,
    DEFAULT_WRITE_POLICY,
    interfaceMap,
    useShallowEntities,
    customIdFromObject,
    typeKeyFactories,
    operationCacheMax: OP_CACHE_MAX,
  });

  // Views (entity/connection views & proxy registration)
  const views = createViews({
    entityStore: graph.entityStore,
    connectionStore: graph.connectionStore,
    ensureConnectionState: graph.ensureConnectionState,
    materializeEntity: graph.materializeEntity,
    makeEntityProxy: graph.makeEntityProxy,
    idOf: graph.idOf,
  });

  /* ───────────────────────────────────────────────────────────────────────────
   * Internals object (exposed to resolvers & plugin)
   * ────────────────────────────────────────────────────────────────────────── */
  const internals: CachebayInternals = {
    TYPENAME_KEY,
    DEFAULT_WRITE_POLICY,
    entityStore: graph.entityStore,
    connectionStore: graph.connectionStore,
    relayResolverIndex,
    relayResolverIndexByType,
    getRelayOptionsByType,
    setRelayOptionsByType,
    operationCache: graph.operationCache,
    putEntity: graph.putEntity,
    materializeEntity: graph.materializeEntity,
    ensureConnectionState: graph.ensureConnectionState,
    synchronizeConnectionViews: views.synchronizeConnectionViews,
    parentEntityKeyFor: graph.parentEntityKeyFor,
    buildConnectionKey,
    readPathValue,
    markConnectionDirty: views.markConnectionDirty,
    linkEntityToConnection: views.linkEntityToConnection,
    unlinkEntityFromConnection: views.unlinkEntityFromConnection,
    touchConnectionsForEntityKey: views.touchConnectionsForEntityKey,
    addStrongView: views.addStrongView,
    isReactive,
    reactive,
    shallowReactive,
    writeOpCache: graph.writeOpCache,
    // filled below:
    applyFieldResolvers: () => { },
  };

  /* ───────────────────────────────────────────────────────────────────────────
   * Resolvers binding + application on graph
   * ────────────────────────────────────────────────────────────────────────── */
  const resolverSource = options.resolvers;
  const resolverSpecs: ResolversDict | undefined =
    typeof resolverSource === "function"
      ? (resolverSource as ResolversFactory)({ relay })
      : (resolverSource as ResolversDict | undefined);

  let FIELD_RESOLVERS: Record<string, Record<string, FieldResolver>> =
    bindResolversTree(resolverSpecs, internals);

  const applyFieldResolvers = makeApplyFieldResolvers({
    TYPENAME_KEY,
    FIELD_RESOLVERS,
  });

  internals.applyFieldResolvers = applyFieldResolvers;

  function applyResolversOnGraph(root: any, vars: Record<string, any>, hint: { stale?: boolean }) {
    applyResolversOnGraphImpl({
      root,
      variables: vars,
      hint,
      FIELD_RESOLVERS,
      TYPENAME_KEY,
    });
  }

  /* ───────────────────────────────────────────────────────────────────────────
   * Register views from result (Relay connections)
   * ────────────────────────────────────────────────────────────────────────── */
  const registerViewsFromResult = (root: any, variables: Record<string, any>) => {
    // Re-using the walker from resolvers implementation would create cycles,
    // so we do a light traversal here tailored for Relay connections.
    const stack: Array<{ obj: any; parentTypename: string | null }> = [{ obj: root, parentTypename: "Query" }];
    while (stack.length) {
      const { obj, parentTypename } = stack.pop()!;
      if (!obj || typeof obj !== "object") continue;

      const pt = (obj as any)[TYPENAME_KEY] || parentTypename;
      const keys = Object.keys(obj);
      for (let i = 0; i < keys.length; i++) {
        const field = keys[i];
        const value = (obj as any)[field];

        // Relay connection spec present?
        const spec = getRelayOptionsByType(pt || null, field);
        if (spec && value && typeof value === "object") {
          // Resolve key/state
          const parentId = (obj as any)?.id ?? (obj as any)?._id;
          const parentKey = graph.parentEntityKeyFor(pt!, parentId) || "Query";
          const connKey = buildConnectionKey(parentKey!, field, spec as any, variables);
          const state = graph.ensureConnectionState(connKey);

          // Extract parts
          const edgesArr = readPathValue(value, spec.segs.edges);
          const pageInfoObj = readPathValue(value, spec.segs.pageInfo);
          if (!edgesArr || !pageInfoObj) continue;

          const edgesField = spec.names.edges;
          const pageInfoField = spec.names.pageInfo;

          const isCursorPage =
            (variables as any)?.after != null || (variables as any)?.before != null;

          // Requested "page" size from variables (fallback to payload size once)
          const pageSize =
            typeof (variables as any)?.first === "number"
              ? (variables as any).first
              : (Array.isArray(edgesArr) ? edgesArr.length : 0);

          // Prepare/reuse parent view container
          let viewObj: any = (obj as any)[field];
          const invalid =
            !viewObj ||
            typeof viewObj !== "object" ||
            !Array.isArray((viewObj as any)[edgesField]) ||
            !(viewObj as any)[pageInfoField];

          if (invalid) {
            viewObj = Object.create(null);
            viewObj.__typename = (value as any)?.__typename ?? "Connection";
            (obj as any)[field] = viewObj;
          }
          if (!isReactive(viewObj[edgesField])) viewObj[edgesField] = reactive(viewObj[edgesField] || []);
          if (!isReactive(viewObj[pageInfoField])) viewObj[pageInfoField] = shallowReactive(viewObj[pageInfoField] || {});

          // Merge connection-level meta
          const exclude = new Set([edgesField, spec.paths.pageInfo, "__typename"]);
          if (value && typeof value === "object") {
            const vk = Object.keys(value);
            for (let vi = 0; vi < vk.length; vi++) {
              const k = vk[vi];
              if (!exclude.has(k)) (state.meta as any)[k] = (value as any)[k];
            }
          }

          // ---- CANONICAL WINDOW: update exactly once per bind ----
          if (!state.initialized) {
            state.window = pageSize;  // first bind = one page
          } else if (isCursorPage) {
            state.window = Math.min(state.list.length, (state.window || 0) + pageSize);
          } else {
            state.window = pageSize;  // baseline reset back to one page
          }

          // Keep exactly one canonical view for this connection key
          state.views.clear();

          views.addStrongView(state, {
            edges: viewObj[edgesField],
            pageInfo: viewObj[pageInfoField],
            root: viewObj,
            edgesKey: edgesField,
            pageInfoKey: pageInfoField,
            pinned: false,
            limit: state.window,       // <- single source of truth
          });

          // Sync so UI renders now with the right window
          views.synchronizeConnectionViews(state);

          if (!state.initialized) state.initialized = true;

          // DEBUG
          // eslint-disable-next-line no-console
          console.debug("sdcsc", variables);
          // eslint-disable-next-line no-console
          console.debug("Connection key:", connKey);
          // eslint-disable-next-line no-console
          console.debug("[views]", Array.from(state.views).map(v => v.limit));
        }

        // Traverse deeper
        const v = (obj as any)[field];
        if (Array.isArray(v)) {
          for (let j = 0; j < (v as any[]).length; j++) {
            const x = (v as any[])[j];
            if (x && typeof x === "object") stack.push({ obj: x, parentTypename: pt || null });
          }
        } else if (v && typeof v === "object") {
          stack.push({ obj: v, parentTypename: pt || null });
        }
      }
    }
  };

  /* ───────────────────────────────────────────────────────────────────────────
   * Collect non-Relay entities
   * ────────────────────────────────────────────────────────────────────────── */
  function collectEntities(root: any) {
    const touchedKeys = new Set<EntityKey>();
    const visited = new WeakSet<object>();
    const stack = [root];

    while (stack.length) {
      const current = stack.pop();
      if (!current || typeof current !== "object") continue;
      if (visited.has(current as object)) continue;
      visited.add(current as object);

      const typename = (current as any)[TYPENAME_KEY];

      if (typename) {
        const ek = graph.idOf(current);
        if (ek) {
          graph.putEntity(current);
          if (trackNonRelayResults) views.registerEntityView(ek, current);
          touchedKeys.add(ek);
        }
      }

      const keys = Object.keys(current as any);
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        const value = (current as any)[k];

        if (!value || typeof value !== "object") continue;

        const opts = getRelayOptionsByType(typename || null, k);
        if (opts) {
          const edges = readPathValue(value, opts.segs.edges);
          if (Array.isArray(edges)) {
            const hasPath = opts.hasNodePath;
            const nodeField = opts.names.nodeField;

            for (let j = 0; j < edges.length; j++) {
              const edge = edges[j];
              if (!edge || typeof edge !== "object") continue;

              const node = hasPath ? readPathValue(edge, opts.segs.node) : (edge as any)[nodeField];
              if (!node || typeof node !== "object") continue;

              const key = graph.idOf(node);
              if (!key) continue;

              graph.putEntity(node);
              touchedKeys.add(key);
            }
          }
          continue;
        }

        stack.push(value);
      }
    }

    touchedKeys.forEach((key) => {
      views.markEntityDirty(key);
      views.touchConnectionsForEntityKey(key);
    });
  }

  // SSR features
  const ssr = createSSRFeatures({
    entityStore: graph.entityStore,
    connectionStore: graph.connectionStore,
    operationCache: graph.operationCache,
    ensureConnectionState: graph.ensureConnectionState,
    linkEntityToConnection: views.linkEntityToConnection,
    shallowReactive,
    registerViewsFromResult,
    resetRuntime: views.resetRuntime,
    applyResolversOnGraph,
    collectEntities,
    materializeResult: views.materializeResult,
  });

  // Build plugin
  const instance = (buildCachebayPlugin(internals, {
    shouldAddTypename,
    opCacheMax: OP_CACHE_MAX,
    isHydrating: ssr.isHydrating,
    hydrateOperationTicket: ssr.hydrateOperationTicket,
    applyResolversOnGraph,
    registerViewsFromResult,
    collectEntities,
  }) as unknown) as CachebayInstance;

  // Fragments API
  const fragments = createFragmentsAPI({
    TYPENAME_KEY,
    entityStore: graph.entityStore,
    idOf: graph.idOf,
    resolveConcreteEntityKey: graph.resolveConcreteEntityKey,
    materializeEntity: graph.materializeEntity,
    bumpEntitiesTick: graph.bumpEntitiesTick,
    isInterfaceTypename: graph.isInterfaceTypename,
    getImplementationsFor: graph.getImplementationsFor,
    proxyForEntityKey: views.proxyForEntityKey,
    markEntityDirty: views.markEntityDirty,
    touchConnectionsForEntityKey: views.touchConnectionsForEntityKey,
  });

  // Wire public API
  (instance as any).dehydrate = ssr.dehydrate;
  (instance as any).hydrate = ssr.hydrate;

  (instance as any).identify = fragments.identify;

  (instance as any).readFragment = fragments.readFragment;
  (instance as any).hasFragment = fragments.hasFragment;
  (instance as any).writeFragment = fragments.writeFragment;

  const modifyOptimistic = createModifyOptimistic(
    {
      entityStore: graph.entityStore,
      connectionStore: graph.connectionStore,

      ensureConnectionState: graph.ensureConnectionState,
      buildConnectionKey,
      parentEntityKeyFor: graph.parentEntityKeyFor,
      getRelayOptionsByType,

      parseEntityKey,
      resolveConcreteEntityKey: graph.resolveConcreteEntityKey,
      doesEntityKeyMatch: graph.doesEntityKeyMatch,
      linkEntityToConnection: views.linkEntityToConnection,
      unlinkEntityFromConnection: views.unlinkEntityFromConnection,
      putEntity: graph.putEntity,
      idOf: graph.idOf,

      markConnectionDirty: views.markConnectionDirty,
      touchConnectionsForEntityKey: views.touchConnectionsForEntityKey,
      markEntityDirty: views.markEntityDirty,
      bumpEntitiesTick: graph.bumpEntitiesTick,

      isInterfaceTypename: (t) => graph.isInterfaceTypename(t),
      getImplementationsFor: (t) => graph.getImplementationsFor(t),
      stableIdentityExcluding,
    },
    {
      identify: fragments.identify,
      readFragment: fragments.readFragment,
      hasFragment: fragments.hasFragment,
      writeFragment: fragments.writeFragment,
    },
  );

  (instance as any).modifyOptimistic = modifyOptimistic;

  (instance as any).inspect = createInspect({
    entityStore: graph.entityStore,
    connectionStore: graph.connectionStore,
    stableIdentityExcluding,
    operationCache: graph.operationCache, // helpful for debugging
  });

  (instance as any).listEntityKeys = (selector: string | string[]) => {
    const types = new Set(
      (Array.isArray(selector) ? selector : [selector]).flatMap((t) =>
        graph.isInterfaceTypename(t) ? graph.getImplementationsFor(t) : [t]
      )
    );
    const keys: string[] = [];
    graph.entityStore.forEach((_v, k) => {
      const { typename } = parseEntityKey(k);
      if (typename && types.has(typename)) keys.push(k);
    });
    return keys;
  };

  (instance as any).listEntities = (selector: string | string[], materialized = true) => {
    const keys = (instance as any).listEntityKeys(selector) as string[];
    if (!materialized) {
      return keys.map((k) => {
        const resolved = graph.resolveConcreteEntityKey(k) || k;
        return graph.entityStore.get(resolved);
      });
    }
    return keys.map((k) => views.proxyForEntityKey(k));
  };

  (instance as any).__entitiesTick = graph.__entitiesTick;

  (instance as any).install = (app: App) => {
    provideCachebay(app, instance);
  };

  (instance as any).gc = {
    connections(predicate?: (key: string, state: ConnectionState) => boolean) {
      views.gcConnections(predicate);
    },
  };

  return instance;
}
